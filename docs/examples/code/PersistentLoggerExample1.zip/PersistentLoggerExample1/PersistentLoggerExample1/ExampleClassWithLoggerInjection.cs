﻿using Plexdata.LogWriter.Abstraction;
using Plexdata.LogWriter.Extensions;
using System;

namespace PersistentLoggerExample1
{
    public class ExampleClassWithLoggerInjection
    {
        private readonly IPersistentLogger logger;

        public ExampleClassWithLoggerInjection(IPersistentLogger logger)
        {
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public void MethodToCall()
        {
            this.logger.Message("Here I am...");
        }
    }
}
