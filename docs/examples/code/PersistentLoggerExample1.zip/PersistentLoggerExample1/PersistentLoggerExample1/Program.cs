﻿using Microsoft.Extensions.DependencyInjection;
using Plexdata.LogWriter.Abstraction;
using Plexdata.LogWriter.Logging;
using Plexdata.LogWriter.Settings;
using System;
using System.IO;

namespace PersistentLoggerExample1
{
    class Program
    {
        static void Main(String[] args)
        {
            ILoggerSettingsBuilder builder = new LoggerSettingsBuilder();
            builder.SetFilename(Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json"));

            IServiceCollection service = new ServiceCollection();
            service.AddSingleton<ILoggerSettingsSection>(builder.Build());
            service.AddSingleton<IPersistentLoggerSettings, PersistentLoggerSettings>();
            service.AddSingleton<IPersistentLogger, PersistentLogger>();
            service.AddTransient(typeof(ExampleClassWithLoggerInjection));

            IServiceProvider provider = service.BuildServiceProvider();

            ExampleClassWithLoggerInjection example = provider.GetService<ExampleClassWithLoggerInjection>();
            example.MethodToCall();

            Console.ReadKey();
        }
    }
}
