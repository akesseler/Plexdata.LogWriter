﻿using Microsoft.Extensions.Configuration;
using Plexdata.LogWriter.Settings;
using System;

namespace ConsoleLoggerExample1
{
    public class ConsoleLoggerConfiguration : ConsoleLoggerSettings
    {
        public ConsoleLoggerConfiguration(IConfigurationRoot config)
            : base()
        {
            if (config == null)
            {
                throw new ArgumentNullException(nameof(config));
            }

            config.GetSection("ConsoleLoggerSettings").Bind(this);
        }
    }
}
