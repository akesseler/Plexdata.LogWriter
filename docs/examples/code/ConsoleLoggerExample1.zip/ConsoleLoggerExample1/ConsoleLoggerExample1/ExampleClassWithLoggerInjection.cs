﻿using Plexdata.LogWriter.Abstraction;
using Plexdata.LogWriter.Extensions;
using System;

namespace ConsoleLoggerExample1
{
    public class ExampleClassWithLoggerInjection
    {
        private readonly IConsoleLogger logger;

        public ExampleClassWithLoggerInjection(IConsoleLogger logger)
        {
            this.logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public void MethodToCall()
        {
            this.logger.Message("Here I am...");
        }
    }
}
