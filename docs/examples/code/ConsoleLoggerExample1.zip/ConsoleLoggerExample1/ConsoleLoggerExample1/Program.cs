﻿using Microsoft.Extensions.DependencyInjection;
using Plexdata.LogWriter.Abstraction;
using Plexdata.LogWriter.Logging.Standard;
using Plexdata.LogWriter.Settings;
using System;
using System.IO;

namespace ConsoleLoggerExample1
{
    class Program
    {
        static void Main(String[] args)
        {
            ILoggerSettingsBuilder builder = new LoggerSettingsBuilder();
            builder.SetFilename(Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json"));

            IServiceCollection service = new ServiceCollection();
            service.AddSingleton<ILoggerSettingsSection>(builder.Build());
            service.AddSingleton<IConsoleLoggerSettings, ConsoleLoggerSettings>();
            service.AddSingleton<IConsoleLogger, ConsoleLogger>();
            service.AddTransient(typeof(ExampleClassWithLoggerInjection));

            IServiceProvider provider = service.BuildServiceProvider();

            ExampleClassWithLoggerInjection example = provider.GetService<ExampleClassWithLoggerInjection>();
            example.MethodToCall();

            Console.ReadKey();
        }
    }
}
