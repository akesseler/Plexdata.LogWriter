﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Plexdata.LogWriter.Abstraction;
using Plexdata.LogWriter.Logging.Standard;
using System;
using System.IO;

namespace ConsoleLoggerExample1
{
    class Program
    {
        static void Main(String[] args)
        {
            IConfigurationBuilder builder = new ConfigurationBuilder();
            builder.SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", false);

            IServiceCollection service = new ServiceCollection();
            service.AddSingleton<IConfigurationRoot>(builder.Build());
            service.AddSingleton<IConsoleLoggerSettings, ConsoleLoggerConfiguration>();
            service.AddSingleton<IConsoleLogger, ConsoleLogger>();
            service.AddTransient(typeof(ExampleClassWithLoggerInjection));

            IServiceProvider provider = service.BuildServiceProvider();

            ExampleClassWithLoggerInjection example = provider.GetService<ExampleClassWithLoggerInjection>();
            example.MethodToCall();

            Console.ReadKey();
        }
    }
}
